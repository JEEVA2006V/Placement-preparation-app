import sqlite3
from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from data import COMPANIES, ROLES, ROLE_DETAILS

app = Flask(__name__)
# Secret key is required to use Flask sessions
app.secret_key = 'super_secret_key_for_placement_app'
db_name = 'placement_app.db'

def init_db():
    """ Initialize SQLite Database for Users """
    conn = sqlite3.connect(db_name)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

@app.route('/')
def index():
    """ Redirect to Dashboard if logged in, otherwise Login """
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    """ Handle user registration """
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        # Hash password before storing in SQLite Database
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')

        try:
            conn = sqlite3.connect(db_name)
            cursor = conn.cursor()
            cursor.execute('INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
                           (username, email, hashed_password))
            conn.commit()
            conn.close()
            flash('Registration successful! Please login to continue.', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Error: Username or Email already exists.', 'danger')
            return redirect(url_for('signup'))
        
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """ Handle user login authentication """
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        conn = sqlite3.connect(db_name)
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE email = ?', (email,))
        user = cursor.fetchone()
        conn.close()

        # Check if user exists and password is correct
        if user and check_password_hash(user[3], password):
            session['user_id'] = user[0]
            session['username'] = user[1]
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid email or password. Try again.', 'danger')
            return redirect(url_for('login'))

    return render_template('login.html')

@app.route('/logout')
def logout():
    """ Clear user session """
    session.pop('user_id', None)
    session.pop('username', None)
    return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    """ Main dashboard hub """
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.html', username=session.get('username'))

@app.route('/department/<dept>')
def department(dept):
    """ View department details and its respective companies """
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    dept = dept.upper() 
    if dept in COMPANIES:
        dept_data = COMPANIES[dept]
        return render_template('department.html', dept=dept, data=dept_data)
    else:
        flash('Requested department was not found.', 'danger')
        return redirect(url_for('dashboard'))

@app.route('/company/<company_id>')
def company(company_id):
    """ Show company profile and available roles """
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    company_details = None
    # Search for company_id within the categories
    for dept, categories in COMPANIES.items():
        for category, companies in categories.items():
            for c in companies:
                if c['id'] == company_id:
                    company_details = c
                    break

    if not company_details:
        flash('Requested company was not found.', 'danger')
        return redirect(url_for('dashboard'))
        
    roles = ROLES.get(company_id, [])
    return render_template('company.html', company=company_details, roles=roles)

@app.route('/role/<role_id>')
def role(role_id):
    """ Detail view for a specific job role to prepare for """
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    role_data = ROLE_DETAILS.get(role_id)
    if not role_data:
        flash('Requested job role was not found.', 'danger')
        return redirect(url_for('dashboard'))
        
    return render_template('role.html', role=role_data)


if __name__ == '__main__':
    # Initialize SQLite database before starting the Flask server
    init_db()
    print("Starting Placement Preparation Web Application...")
    print("Listening on http://127.0.0.1:5000/")
    app.run(debug=True, port=5000)
