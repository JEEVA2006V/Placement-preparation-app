// Add simple entrance animations for glass cards and interactivity
document.addEventListener("DOMContentLoaded", () => {
    const cards = document.querySelectorAll('.glass-card');
    
    // Animate cards sequentially to create a cascading entrance effect
    cards.forEach((card, index) => {
        card.animate([
            { opacity: 0, transform: 'translateY(30px)' },
            { opacity: 1, transform: 'translateY(0)' }
        ], {
            duration: 600,
            delay: index * 80, // Adjust delay multiplier for staggered effect
            fill: 'both',
            easing: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)'
        });
    });

    // Auto-dismiss Flash Messages after 5 seconds if present
    const flashMessages = document.querySelectorAll('.flash-msg');
    if(flashMessages.length > 0) {
        setTimeout(() => {
            flashMessages.forEach(msg => {
                msg.animate([
                    { opacity: 1, transform: 'translateY(0)' },
                    { opacity: 0, transform: 'translateY(-10px)' }
                ], {
                    duration: 400,
                    fill: 'both',
                    easing: 'ease-in'
                });
                // Remove from DOM after animation
                setTimeout(() => msg.remove(), 400);
            });
        }, 5000); // 5000ms = 5 seconds
    }
});
