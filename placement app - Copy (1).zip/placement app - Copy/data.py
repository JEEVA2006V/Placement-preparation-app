# data.py
# Contains dictionaries to mock JSON responses for Companies, Roles and Skills

# Dictionary containing companies grouped by department and category
COMPANIES = {
    "ECE": {
        "Top Companies": [
            {
                "id": "qualcomm",
                "name": "Qualcomm",
                "profile": "Leading global wireless telecommunications products and services company.",
                "domain": "Hardware/Telecom",
                "career_link": "https://careers.qualcomm.com/"
            },
            {
                "id": "intel",
                "name": "Intel",
                "profile": "Multinational corporation and technology company, largest semiconductor chip manufacturer.",
                "domain": "Hardware",
                "career_link": "https://jobs.intel.com/"
            }
        ],
        "Mid-level Companies": [
            {
                "id": "tata-elxsi",
                "name": "Tata Elxsi",
                "profile": "Global provider of design and technology services across industries.",
                "domain": "Hardware/Software Design",
                "career_link": "https://www.tataelxsi.com/careers"
            }
        ],
        "Mass Recruiters": [
            {
                "id": "tcs",
                "name": "TCS (Tata Consultancy Services)",
                "profile": "Indian multinational IT services and consulting company.",
                "domain": "Software/IT Services",
                "career_link": "https://www.tcs.com/careers"
            },
            {
                "id": "cognizant",
                "name": "Cognizant",
                "profile": "Multinational IT technology and consulting company.",
                "domain": "Software/IT Services",
                "career_link": "https://careers.cognizant.com/"
            }
        ]
    }
}

# Job Roles linked to specific company IDs
ROLES = {
    "qualcomm": [
        {"id": "hardware-engineer", "name": "Hardware Engineer"},
        {"id": "embedded-software-engineer", "name": "Embedded Software Engineer"}
    ],
    "intel": [
        {"id": "hardware-engineer", "name": "Hardware Engineer"},
        {"id": "systems-engineer", "name": "Systems Engineer"}
    ],
    "tata-elxsi": [
        {"id": "embedded-developer", "name": "Embedded Developer"},
    ],
    "tcs": [
        {"id": "system-engineer", "name": "System Engineer (Ninja / Digital)"}
    ],
    "cognizant": [
        {"id": "programmer-analyst", "name": "Programmer Analyst Trainee"}
    ]
}

# Specific requirements and learning roadmaps for every Job Role
ROLE_DETAILS = {
    "hardware-engineer": {
        "name": "Hardware Engineer",
        "skills": ["Digital Logic", "Verilog/VHDL", "Computer Architecture", "VLSI Design"],
        "roadmap": [
            "1. Revise Digital logic and Boolean algebra fundamentals",
            "2. Learn a hardware description language (Verilog/VHDL)",
            "3. FPGA design basics and timing constraints",
            "4. Computer architecture & organization mapping",
            "5. Advanced VLSI design concepts and layout rules"
        ],
        "links": [
            {"title": "NPTEL VLSI Design Course", "url": "https://nptel.ac.in/"},
            {"title": "Verilog Tutorial (ChipVerify)", "url": "https://www.chipverify.com/verilog/verilog-tutorial"}
        ],
        "last_updated": "2026-03-30"
    },
    "embedded-software-engineer": {
        "name": "Embedded Software Engineer",
        "skills": ["C/C++", "Microcontrollers", "RTOS", "Linux", "Device Drivers"],
        "roadmap": [
            "1. Master C programming with emphasis on pointers and memory",
            "2. Learn microcontroller architecture (e.g., ARM Cortex-M)",
            "3. Understand communication protocols (I2C, SPI, UART, CAN)",
            "4. Real-Time Operating Systems (RTOS) basics and task scheduling",
            "5. Embedded Linux & Device Drivers basics"
        ],
        "links": [
            {"title": "Embedded Systems Tutorial", "url": "https://www.tutorialspoint.com/embedded_systems/index.htm"},
            {"title": "FreeRTOS Documentation", "url": "https://www.freertos.org/"}
        ],
        "last_updated": "2026-03-30"
    },
    "system-engineer": {
         "name": "System Engineer",
         "skills": ["Python / Java", "SQL", "Data Structures & Algorithms", "Aptitude"],
         "roadmap": [
             "1. Master one object-oriented programming language (Java, C++, or Python)",
             "2. Strong foundation in Data Structures (Arrays, Linked Lists, Trees) and Algorithms",
             "3. Relational Database Concepts (DBMS) and SQL queries",
             "4. Practice General Aptitude & Logical Reasoning (crucial for mass recruiters)"
         ],
         "links": [
            {"title": "GeeksforGeeks placement practice", "url": "https://www.geeksforgeeks.org/"},
            {"title": "IndiaBix Aptitude test preparation", "url": "https://www.indiabix.com/"}
         ],
         "last_updated": "2026-03-30"
    },
    "programmer-analyst": {
         "name": "Programmer Analyst Trainee",
         "skills": ["C/C++/Java", "DBMS & SQL", "Software Engineering lifecycle"],
         "roadmap": [
             "1. Ensure solid programming fundamentals",
             "2. Practice problem solving on coding platforms to clear coding rounds",
             "3. Know your Object Oriented Programming (OOP) concepts by heart",
             "4. Relational Database Management theory and queries"
         ],
         "links": [
            {"title": "LeetCode interview prep", "url": "https://leetcode.com/"},
            {"title": "W3Schools SQL Tutorial", "url": "https://www.w3schools.com/sql/"}
         ],
         "last_updated": "2026-03-30"
    },
    "embedded-developer": {
         "name": "Embedded Developer",
         "skills": ["Advanced C", "Microprocessors", "Hardware Debugging"],
         "roadmap": [
             "1. Advanced C concepts (Bitwise ops, Pointers, Memory Management)",
             "2. Bare-metal programming vs OS programming",
             "3. Reading datasheets efficiently",
             "4. Debugging hardware using JTAG/SWD tools"
         ],
         "links": [
            {"title": "C Programming FAQs", "url": "https://c-faq.com/"}
         ],
         "last_updated": "2026-03-30"
    },
    "systems-engineer": {
         "name": "Systems Engineer",
         "skills": ["Linux Kernel", "C Programming", "Computer Networks"],
         "roadmap": [
             "1. Operating System Internals (Processes, Threads, Concurrency)",
             "2. System-level programming in C (POSIX APIs)",
             "3. Advanced Computer Networks (TCP/IP stack, layering)"
         ],
         "links": [
            {"title": "Linux Journey (OS & CLI basics)", "url": "https://linuxjourney.com/"}
         ],
         "last_updated": "2026-03-30"
    }
}
